﻿
namespace Talep_Yogunlugunun_Multithread_Kontrolu.UI
{
    partial class ShoppingMallInformationDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShoppingMallInformationDisplay));
            this.tbl3ModUc = new System.Windows.Forms.Label();
            this.tbl3ModDort = new System.Windows.Forms.Label();
            this.tbl3KuyrukDort = new System.Windows.Forms.Label();
            this.tbl3KuyrukUc = new System.Windows.Forms.Label();
            this.tbl3ModIki = new System.Windows.Forms.Label();
            this.tbl3KuyrukIki = new System.Windows.Forms.Label();
            this.tbl3KuyrukBir = new System.Windows.Forms.Label();
            this.tbl3KuyrukSifir = new System.Windows.Forms.Label();
            this.tbl3KUYRUK = new System.Windows.Forms.Label();
            this.tbl3AsansorDort = new System.Windows.Forms.Label();
            this.tbl3AsansorUc = new System.Windows.Forms.Label();
            this.tbl3AsansorIki = new System.Windows.Forms.Label();
            this.tbl3AsansorBir = new System.Windows.Forms.Label();
            this.tbl3AsansorSifir = new System.Windows.Forms.Label();
            this.tbl3Asansor = new System.Windows.Forms.Label();
            this.tbl3MOD = new System.Windows.Forms.Label();
            this.tbl3ModSifir = new System.Windows.Forms.Label();
            this.tbl3ModBir = new System.Windows.Forms.Label();
            this.tbl3KatDort = new System.Windows.Forms.Label();
            this.tbl3KatUc = new System.Windows.Forms.Label();
            this.tbl3HedefDort = new System.Windows.Forms.Label();
            this.tbl3HedefUc = new System.Windows.Forms.Label();
            this.tbl3YonDort = new System.Windows.Forms.Label();
            this.tbl3YonUc = new System.Windows.Forms.Label();
            this.tbl3AnlikDort = new System.Windows.Forms.Label();
            this.tbl3AnlikUc = new System.Windows.Forms.Label();
            this.tbl3KAT = new System.Windows.Forms.Label();
            this.tbl3KatSifir = new System.Windows.Forms.Label();
            this.tbl3KatBir = new System.Windows.Forms.Label();
            this.tbl3KatIki = new System.Windows.Forms.Label();
            this.tbl3HedefIki = new System.Windows.Forms.Label();
            this.tbl3HedefBir = new System.Windows.Forms.Label();
            this.tbl3HedefSifir = new System.Windows.Forms.Label();
            this.tbl3HEDEF = new System.Windows.Forms.Label();
            this.tbl3YON = new System.Windows.Forms.Label();
            this.tbl3YonSifir = new System.Windows.Forms.Label();
            this.tbl3YonBir = new System.Windows.Forms.Label();
            this.tbl3YonIki = new System.Windows.Forms.Label();
            this.tbl3ANLIK = new System.Windows.Forms.Label();
            this.tbl3AnlikSifir = new System.Windows.Forms.Label();
            this.tbl3AnlikBir = new System.Windows.Forms.Label();
            this.tbl3AnlikIki = new System.Windows.Forms.Label();
            this.tbl2KatDort = new System.Windows.Forms.Label();
            this.tbl2KuyrukDort = new System.Windows.Forms.Label();
            this.tbl2KuyrukUc = new System.Windows.Forms.Label();
            this.tbl2KatUc = new System.Windows.Forms.Label();
            this.tbl2KuyrukIki = new System.Windows.Forms.Label();
            this.tbl2KatIki = new System.Windows.Forms.Label();
            this.tbl2KuyrukBir = new System.Windows.Forms.Label();
            this.tbl2KatBir = new System.Windows.Forms.Label();
            this.tbl2KuyrukZemin = new System.Windows.Forms.Label();
            this.tbl2KatZemin = new System.Windows.Forms.Label();
            this.tbl2KUYRUK = new System.Windows.Forms.Label();
            this.tbl2KAT = new System.Windows.Forms.Label();
            this.tbl1KuyrukDort = new System.Windows.Forms.Label();
            this.tbl1KuyrukUc = new System.Windows.Forms.Label();
            this.tbl1KuyrukIki = new System.Windows.Forms.Label();
            this.tbl1KuyrukBir = new System.Windows.Forms.Label();
            this.tbl1KuyrukZemin = new System.Windows.Forms.Label();
            this.tbl1KUYRUKTABEKLEYENSAYISI = new System.Windows.Forms.Label();
            this.tbl1KISISAYISI = new System.Windows.Forms.Label();
            this.tbl1KATBILGISI = new System.Windows.Forms.Label();
            this.tbl1KatBilgDortKt = new System.Windows.Forms.Label();
            this.tbl1KisiSayisiDort = new System.Windows.Forms.Label();
            this.tbl1KisiSayisiUc = new System.Windows.Forms.Label();
            this.tbl1KatBilgUcKt = new System.Windows.Forms.Label();
            this.tbl1KatBilgIkiKt = new System.Windows.Forms.Label();
            this.tbl1KatBilgBirKt = new System.Windows.Forms.Label();
            this.tbl1KatBilgZeminKt = new System.Windows.Forms.Label();
            this.tbl1KisiSayisiIki = new System.Windows.Forms.Label();
            this.tbl1KisiSayisiBir = new System.Windows.Forms.Label();
            this.tbl1KisiSayisiZemin = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.LoginThreadCount = new System.Windows.Forms.Label();
            this.StartBtn = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.LogoutThreadCount = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.CapacityLbl = new System.Windows.Forms.Label();
            this.LoginThreadSpeedLbl = new System.Windows.Forms.Label();
            this.ExitThreadSpeedLbl = new System.Windows.Forms.Label();
            this.ElevatorSpeedLbl = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbl3ModUc
            // 
            this.tbl3ModUc.AutoSize = true;
            this.tbl3ModUc.BackColor = System.Drawing.Color.Transparent;
            this.tbl3ModUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3ModUc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(3)))), ((int)(((byte)(9)))));
            this.tbl3ModUc.Location = new System.Drawing.Point(117, 140);
            this.tbl3ModUc.Name = "tbl3ModUc";
            this.tbl3ModUc.Size = new System.Drawing.Size(23, 15);
            this.tbl3ModUc.TabIndex = 57;
            this.tbl3ModUc.Text = "----";
            // 
            // tbl3ModDort
            // 
            this.tbl3ModDort.AutoSize = true;
            this.tbl3ModDort.BackColor = System.Drawing.Color.Transparent;
            this.tbl3ModDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3ModDort.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(3)))), ((int)(((byte)(9)))));
            this.tbl3ModDort.Location = new System.Drawing.Point(117, 170);
            this.tbl3ModDort.Name = "tbl3ModDort";
            this.tbl3ModDort.Size = new System.Drawing.Size(23, 15);
            this.tbl3ModDort.TabIndex = 13;
            this.tbl3ModDort.Text = "----";
            // 
            // tbl3KuyrukDort
            // 
            this.tbl3KuyrukDort.AutoSize = true;
            this.tbl3KuyrukDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KuyrukDort.Location = new System.Drawing.Point(623, 170);
            this.tbl3KuyrukDort.Name = "tbl3KuyrukDort";
            this.tbl3KuyrukDort.Size = new System.Drawing.Size(23, 15);
            this.tbl3KuyrukDort.TabIndex = 56;
            this.tbl3KuyrukDort.Text = "----";
            // 
            // tbl3KuyrukUc
            // 
            this.tbl3KuyrukUc.AutoSize = true;
            this.tbl3KuyrukUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KuyrukUc.Location = new System.Drawing.Point(623, 140);
            this.tbl3KuyrukUc.Name = "tbl3KuyrukUc";
            this.tbl3KuyrukUc.Size = new System.Drawing.Size(23, 15);
            this.tbl3KuyrukUc.TabIndex = 55;
            this.tbl3KuyrukUc.Text = "----";
            // 
            // tbl3ModIki
            // 
            this.tbl3ModIki.AutoSize = true;
            this.tbl3ModIki.BackColor = System.Drawing.Color.Transparent;
            this.tbl3ModIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3ModIki.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(3)))), ((int)(((byte)(9)))));
            this.tbl3ModIki.Location = new System.Drawing.Point(117, 110);
            this.tbl3ModIki.Name = "tbl3ModIki";
            this.tbl3ModIki.Size = new System.Drawing.Size(23, 15);
            this.tbl3ModIki.TabIndex = 11;
            this.tbl3ModIki.Text = "----";
            // 
            // tbl3KuyrukIki
            // 
            this.tbl3KuyrukIki.AutoSize = true;
            this.tbl3KuyrukIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KuyrukIki.Location = new System.Drawing.Point(623, 110);
            this.tbl3KuyrukIki.Name = "tbl3KuyrukIki";
            this.tbl3KuyrukIki.Size = new System.Drawing.Size(23, 15);
            this.tbl3KuyrukIki.TabIndex = 54;
            this.tbl3KuyrukIki.Text = "----";
            // 
            // tbl3KuyrukBir
            // 
            this.tbl3KuyrukBir.AutoSize = true;
            this.tbl3KuyrukBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KuyrukBir.Location = new System.Drawing.Point(623, 80);
            this.tbl3KuyrukBir.Name = "tbl3KuyrukBir";
            this.tbl3KuyrukBir.Size = new System.Drawing.Size(23, 15);
            this.tbl3KuyrukBir.TabIndex = 53;
            this.tbl3KuyrukBir.Text = "----";
            // 
            // tbl3KuyrukSifir
            // 
            this.tbl3KuyrukSifir.AutoSize = true;
            this.tbl3KuyrukSifir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KuyrukSifir.Location = new System.Drawing.Point(623, 50);
            this.tbl3KuyrukSifir.Name = "tbl3KuyrukSifir";
            this.tbl3KuyrukSifir.Size = new System.Drawing.Size(23, 15);
            this.tbl3KuyrukSifir.TabIndex = 52;
            this.tbl3KuyrukSifir.Text = "----";
            // 
            // tbl3KUYRUK
            // 
            this.tbl3KUYRUK.AutoSize = true;
            this.tbl3KUYRUK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KUYRUK.Location = new System.Drawing.Point(615, 20);
            this.tbl3KUYRUK.Name = "tbl3KUYRUK";
            this.tbl3KUYRUK.Size = new System.Drawing.Size(216, 15);
            this.tbl3KUYRUK.TabIndex = 8;
            this.tbl3KUYRUK.Text = "ASANSÖRDE BULUNAN KİŞİLER";
            // 
            // tbl3AsansorDort
            // 
            this.tbl3AsansorDort.AutoSize = true;
            this.tbl3AsansorDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AsansorDort.Location = new System.Drawing.Point(40, 170);
            this.tbl3AsansorDort.Name = "tbl3AsansorDort";
            this.tbl3AsansorDort.Size = new System.Drawing.Size(23, 15);
            this.tbl3AsansorDort.TabIndex = 44;
            this.tbl3AsansorDort.Text = "----";
            // 
            // tbl3AsansorUc
            // 
            this.tbl3AsansorUc.AutoSize = true;
            this.tbl3AsansorUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AsansorUc.Location = new System.Drawing.Point(40, 140);
            this.tbl3AsansorUc.Name = "tbl3AsansorUc";
            this.tbl3AsansorUc.Size = new System.Drawing.Size(23, 15);
            this.tbl3AsansorUc.TabIndex = 35;
            this.tbl3AsansorUc.Text = "----";
            // 
            // tbl3AsansorIki
            // 
            this.tbl3AsansorIki.AutoSize = true;
            this.tbl3AsansorIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AsansorIki.Location = new System.Drawing.Point(40, 110);
            this.tbl3AsansorIki.Name = "tbl3AsansorIki";
            this.tbl3AsansorIki.Size = new System.Drawing.Size(23, 15);
            this.tbl3AsansorIki.TabIndex = 26;
            this.tbl3AsansorIki.Text = "----";
            // 
            // tbl3AsansorBir
            // 
            this.tbl3AsansorBir.AutoSize = true;
            this.tbl3AsansorBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AsansorBir.Location = new System.Drawing.Point(40, 80);
            this.tbl3AsansorBir.Name = "tbl3AsansorBir";
            this.tbl3AsansorBir.Size = new System.Drawing.Size(23, 15);
            this.tbl3AsansorBir.TabIndex = 17;
            this.tbl3AsansorBir.Text = "----";
            // 
            // tbl3AsansorSifir
            // 
            this.tbl3AsansorSifir.AutoSize = true;
            this.tbl3AsansorSifir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AsansorSifir.Location = new System.Drawing.Point(40, 50);
            this.tbl3AsansorSifir.Name = "tbl3AsansorSifir";
            this.tbl3AsansorSifir.Size = new System.Drawing.Size(23, 15);
            this.tbl3AsansorSifir.TabIndex = 2;
            this.tbl3AsansorSifir.Text = "----";
            // 
            // tbl3Asansor
            // 
            this.tbl3Asansor.AutoSize = true;
            this.tbl3Asansor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3Asansor.Location = new System.Drawing.Point(20, 20);
            this.tbl3Asansor.Name = "tbl3Asansor";
            this.tbl3Asansor.Size = new System.Drawing.Size(71, 15);
            this.tbl3Asansor.TabIndex = 0;
            this.tbl3Asansor.Text = "ASANSÖR";
            // 
            // tbl3MOD
            // 
            this.tbl3MOD.AutoSize = true;
            this.tbl3MOD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3MOD.Location = new System.Drawing.Point(117, 20);
            this.tbl3MOD.Name = "tbl3MOD";
            this.tbl3MOD.Size = new System.Drawing.Size(59, 15);
            this.tbl3MOD.TabIndex = 2;
            this.tbl3MOD.Text = "DURUM";
            // 
            // tbl3ModSifir
            // 
            this.tbl3ModSifir.AutoSize = true;
            this.tbl3ModSifir.BackColor = System.Drawing.Color.Transparent;
            this.tbl3ModSifir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3ModSifir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(3)))), ((int)(((byte)(9)))));
            this.tbl3ModSifir.Location = new System.Drawing.Point(117, 50);
            this.tbl3ModSifir.Name = "tbl3ModSifir";
            this.tbl3ModSifir.Size = new System.Drawing.Size(23, 15);
            this.tbl3ModSifir.TabIndex = 10;
            this.tbl3ModSifir.Text = "----";
            // 
            // tbl3ModBir
            // 
            this.tbl3ModBir.AutoSize = true;
            this.tbl3ModBir.BackColor = System.Drawing.Color.Transparent;
            this.tbl3ModBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3ModBir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(3)))), ((int)(((byte)(9)))));
            this.tbl3ModBir.Location = new System.Drawing.Point(117, 80);
            this.tbl3ModBir.Name = "tbl3ModBir";
            this.tbl3ModBir.Size = new System.Drawing.Size(23, 15);
            this.tbl3ModBir.TabIndex = 19;
            this.tbl3ModBir.Text = "----";
            // 
            // tbl3KatDort
            // 
            this.tbl3KatDort.AutoSize = true;
            this.tbl3KatDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KatDort.Location = new System.Drawing.Point(210, 170);
            this.tbl3KatDort.Name = "tbl3KatDort";
            this.tbl3KatDort.Size = new System.Drawing.Size(23, 15);
            this.tbl3KatDort.TabIndex = 47;
            this.tbl3KatDort.Text = "----";
            // 
            // tbl3KatUc
            // 
            this.tbl3KatUc.AutoSize = true;
            this.tbl3KatUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KatUc.Location = new System.Drawing.Point(210, 140);
            this.tbl3KatUc.Name = "tbl3KatUc";
            this.tbl3KatUc.Size = new System.Drawing.Size(23, 15);
            this.tbl3KatUc.TabIndex = 38;
            this.tbl3KatUc.Text = "----";
            // 
            // tbl3HedefDort
            // 
            this.tbl3HedefDort.AutoSize = true;
            this.tbl3HedefDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3HedefDort.Location = new System.Drawing.Point(291, 170);
            this.tbl3HedefDort.Name = "tbl3HedefDort";
            this.tbl3HedefDort.Size = new System.Drawing.Size(23, 15);
            this.tbl3HedefDort.TabIndex = 48;
            this.tbl3HedefDort.Text = "----";
            // 
            // tbl3HedefUc
            // 
            this.tbl3HedefUc.AutoSize = true;
            this.tbl3HedefUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3HedefUc.Location = new System.Drawing.Point(291, 140);
            this.tbl3HedefUc.Name = "tbl3HedefUc";
            this.tbl3HedefUc.Size = new System.Drawing.Size(23, 15);
            this.tbl3HedefUc.TabIndex = 39;
            this.tbl3HedefUc.Text = "----";
            // 
            // tbl3YonDort
            // 
            this.tbl3YonDort.AutoSize = true;
            this.tbl3YonDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3YonDort.Location = new System.Drawing.Point(371, 170);
            this.tbl3YonDort.Name = "tbl3YonDort";
            this.tbl3YonDort.Size = new System.Drawing.Size(23, 15);
            this.tbl3YonDort.TabIndex = 49;
            this.tbl3YonDort.Text = "----";
            // 
            // tbl3YonUc
            // 
            this.tbl3YonUc.AutoSize = true;
            this.tbl3YonUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3YonUc.Location = new System.Drawing.Point(371, 140);
            this.tbl3YonUc.Name = "tbl3YonUc";
            this.tbl3YonUc.Size = new System.Drawing.Size(23, 15);
            this.tbl3YonUc.TabIndex = 40;
            this.tbl3YonUc.Text = "----";
            // 
            // tbl3AnlikDort
            // 
            this.tbl3AnlikDort.AutoSize = true;
            this.tbl3AnlikDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AnlikDort.Location = new System.Drawing.Point(498, 170);
            this.tbl3AnlikDort.Name = "tbl3AnlikDort";
            this.tbl3AnlikDort.Size = new System.Drawing.Size(23, 15);
            this.tbl3AnlikDort.TabIndex = 51;
            this.tbl3AnlikDort.Text = "----";
            // 
            // tbl3AnlikUc
            // 
            this.tbl3AnlikUc.AutoSize = true;
            this.tbl3AnlikUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AnlikUc.Location = new System.Drawing.Point(498, 140);
            this.tbl3AnlikUc.Name = "tbl3AnlikUc";
            this.tbl3AnlikUc.Size = new System.Drawing.Size(23, 15);
            this.tbl3AnlikUc.TabIndex = 42;
            this.tbl3AnlikUc.Text = "----";
            // 
            // tbl3KAT
            // 
            this.tbl3KAT.AutoSize = true;
            this.tbl3KAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KAT.Location = new System.Drawing.Point(205, 20);
            this.tbl3KAT.Name = "tbl3KAT";
            this.tbl3KAT.Size = new System.Drawing.Size(32, 15);
            this.tbl3KAT.TabIndex = 3;
            this.tbl3KAT.Text = "KAT";
            // 
            // tbl3KatSifir
            // 
            this.tbl3KatSifir.AutoSize = true;
            this.tbl3KatSifir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KatSifir.Location = new System.Drawing.Point(210, 50);
            this.tbl3KatSifir.Name = "tbl3KatSifir";
            this.tbl3KatSifir.Size = new System.Drawing.Size(23, 15);
            this.tbl3KatSifir.TabIndex = 11;
            this.tbl3KatSifir.Text = "----";
            // 
            // tbl3KatBir
            // 
            this.tbl3KatBir.AutoSize = true;
            this.tbl3KatBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KatBir.Location = new System.Drawing.Point(210, 80);
            this.tbl3KatBir.Name = "tbl3KatBir";
            this.tbl3KatBir.Size = new System.Drawing.Size(23, 15);
            this.tbl3KatBir.TabIndex = 20;
            this.tbl3KatBir.Text = "----";
            // 
            // tbl3KatIki
            // 
            this.tbl3KatIki.AutoSize = true;
            this.tbl3KatIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3KatIki.Location = new System.Drawing.Point(210, 110);
            this.tbl3KatIki.Name = "tbl3KatIki";
            this.tbl3KatIki.Size = new System.Drawing.Size(23, 15);
            this.tbl3KatIki.TabIndex = 29;
            this.tbl3KatIki.Text = "----";
            // 
            // tbl3HedefIki
            // 
            this.tbl3HedefIki.AutoSize = true;
            this.tbl3HedefIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3HedefIki.Location = new System.Drawing.Point(291, 110);
            this.tbl3HedefIki.Name = "tbl3HedefIki";
            this.tbl3HedefIki.Size = new System.Drawing.Size(23, 15);
            this.tbl3HedefIki.TabIndex = 30;
            this.tbl3HedefIki.Text = "----";
            // 
            // tbl3HedefBir
            // 
            this.tbl3HedefBir.AutoSize = true;
            this.tbl3HedefBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3HedefBir.Location = new System.Drawing.Point(291, 80);
            this.tbl3HedefBir.Name = "tbl3HedefBir";
            this.tbl3HedefBir.Size = new System.Drawing.Size(23, 15);
            this.tbl3HedefBir.TabIndex = 21;
            this.tbl3HedefBir.Text = "----";
            // 
            // tbl3HedefSifir
            // 
            this.tbl3HedefSifir.AutoSize = true;
            this.tbl3HedefSifir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3HedefSifir.Location = new System.Drawing.Point(291, 50);
            this.tbl3HedefSifir.Name = "tbl3HedefSifir";
            this.tbl3HedefSifir.Size = new System.Drawing.Size(23, 15);
            this.tbl3HedefSifir.TabIndex = 12;
            this.tbl3HedefSifir.Text = "----";
            // 
            // tbl3HEDEF
            // 
            this.tbl3HEDEF.AutoSize = true;
            this.tbl3HEDEF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3HEDEF.Location = new System.Drawing.Point(276, 20);
            this.tbl3HEDEF.Name = "tbl3HEDEF";
            this.tbl3HEDEF.Size = new System.Drawing.Size(53, 15);
            this.tbl3HEDEF.TabIndex = 4;
            this.tbl3HEDEF.Text = "HEDEF";
            // 
            // tbl3YON
            // 
            this.tbl3YON.AutoSize = true;
            this.tbl3YON.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3YON.Location = new System.Drawing.Point(371, 20);
            this.tbl3YON.Name = "tbl3YON";
            this.tbl3YON.Size = new System.Drawing.Size(35, 15);
            this.tbl3YON.TabIndex = 5;
            this.tbl3YON.Text = "YÖN";
            // 
            // tbl3YonSifir
            // 
            this.tbl3YonSifir.AutoSize = true;
            this.tbl3YonSifir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3YonSifir.Location = new System.Drawing.Point(371, 50);
            this.tbl3YonSifir.Name = "tbl3YonSifir";
            this.tbl3YonSifir.Size = new System.Drawing.Size(23, 15);
            this.tbl3YonSifir.TabIndex = 13;
            this.tbl3YonSifir.Text = "----";
            // 
            // tbl3YonBir
            // 
            this.tbl3YonBir.AutoSize = true;
            this.tbl3YonBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3YonBir.Location = new System.Drawing.Point(371, 80);
            this.tbl3YonBir.Name = "tbl3YonBir";
            this.tbl3YonBir.Size = new System.Drawing.Size(23, 15);
            this.tbl3YonBir.TabIndex = 22;
            this.tbl3YonBir.Text = "----";
            // 
            // tbl3YonIki
            // 
            this.tbl3YonIki.AutoSize = true;
            this.tbl3YonIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3YonIki.Location = new System.Drawing.Point(371, 110);
            this.tbl3YonIki.Name = "tbl3YonIki";
            this.tbl3YonIki.Size = new System.Drawing.Size(23, 15);
            this.tbl3YonIki.TabIndex = 31;
            this.tbl3YonIki.Text = "----";
            // 
            // tbl3ANLIK
            // 
            this.tbl3ANLIK.AutoSize = true;
            this.tbl3ANLIK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3ANLIK.Location = new System.Drawing.Point(458, 20);
            this.tbl3ANLIK.Name = "tbl3ANLIK";
            this.tbl3ANLIK.Size = new System.Drawing.Size(122, 15);
            this.tbl3ANLIK.TabIndex = 7;
            this.tbl3ANLIK.Text = "ANLIK KİŞİ SAYISI";
            // 
            // tbl3AnlikSifir
            // 
            this.tbl3AnlikSifir.AutoSize = true;
            this.tbl3AnlikSifir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AnlikSifir.Location = new System.Drawing.Point(498, 50);
            this.tbl3AnlikSifir.Name = "tbl3AnlikSifir";
            this.tbl3AnlikSifir.Size = new System.Drawing.Size(23, 15);
            this.tbl3AnlikSifir.TabIndex = 15;
            this.tbl3AnlikSifir.Text = "----";
            // 
            // tbl3AnlikBir
            // 
            this.tbl3AnlikBir.AutoSize = true;
            this.tbl3AnlikBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AnlikBir.Location = new System.Drawing.Point(498, 80);
            this.tbl3AnlikBir.Name = "tbl3AnlikBir";
            this.tbl3AnlikBir.Size = new System.Drawing.Size(23, 15);
            this.tbl3AnlikBir.TabIndex = 24;
            this.tbl3AnlikBir.Text = "----";
            // 
            // tbl3AnlikIki
            // 
            this.tbl3AnlikIki.AutoSize = true;
            this.tbl3AnlikIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbl3AnlikIki.Location = new System.Drawing.Point(498, 110);
            this.tbl3AnlikIki.Name = "tbl3AnlikIki";
            this.tbl3AnlikIki.Size = new System.Drawing.Size(23, 15);
            this.tbl3AnlikIki.TabIndex = 33;
            this.tbl3AnlikIki.Text = "----";
            // 
            // tbl2KatDort
            // 
            this.tbl2KatDort.AutoSize = true;
            this.tbl2KatDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KatDort.Location = new System.Drawing.Point(42, 170);
            this.tbl2KatDort.Name = "tbl2KatDort";
            this.tbl2KatDort.Size = new System.Drawing.Size(38, 15);
            this.tbl2KatDort.TabIndex = 11;
            this.tbl2KatDort.Text = "4. Kat";
            // 
            // tbl2KuyrukDort
            // 
            this.tbl2KuyrukDort.AutoSize = true;
            this.tbl2KuyrukDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KuyrukDort.Location = new System.Drawing.Point(131, 170);
            this.tbl2KuyrukDort.Name = "tbl2KuyrukDort";
            this.tbl2KuyrukDort.Size = new System.Drawing.Size(23, 15);
            this.tbl2KuyrukDort.TabIndex = 10;
            this.tbl2KuyrukDort.Text = "----";
            // 
            // tbl2KuyrukUc
            // 
            this.tbl2KuyrukUc.AutoSize = true;
            this.tbl2KuyrukUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KuyrukUc.Location = new System.Drawing.Point(131, 140);
            this.tbl2KuyrukUc.Name = "tbl2KuyrukUc";
            this.tbl2KuyrukUc.Size = new System.Drawing.Size(23, 15);
            this.tbl2KuyrukUc.TabIndex = 9;
            this.tbl2KuyrukUc.Text = "----";
            // 
            // tbl2KatUc
            // 
            this.tbl2KatUc.AutoSize = true;
            this.tbl2KatUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KatUc.Location = new System.Drawing.Point(42, 140);
            this.tbl2KatUc.Name = "tbl2KatUc";
            this.tbl2KatUc.Size = new System.Drawing.Size(38, 15);
            this.tbl2KatUc.TabIndex = 8;
            this.tbl2KatUc.Text = "3. Kat";
            // 
            // tbl2KuyrukIki
            // 
            this.tbl2KuyrukIki.AutoSize = true;
            this.tbl2KuyrukIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KuyrukIki.Location = new System.Drawing.Point(131, 110);
            this.tbl2KuyrukIki.Name = "tbl2KuyrukIki";
            this.tbl2KuyrukIki.Size = new System.Drawing.Size(23, 15);
            this.tbl2KuyrukIki.TabIndex = 7;
            this.tbl2KuyrukIki.Text = "----";
            // 
            // tbl2KatIki
            // 
            this.tbl2KatIki.AutoSize = true;
            this.tbl2KatIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KatIki.Location = new System.Drawing.Point(42, 110);
            this.tbl2KatIki.Name = "tbl2KatIki";
            this.tbl2KatIki.Size = new System.Drawing.Size(38, 15);
            this.tbl2KatIki.TabIndex = 6;
            this.tbl2KatIki.Text = "2. Kat";
            // 
            // tbl2KuyrukBir
            // 
            this.tbl2KuyrukBir.AutoSize = true;
            this.tbl2KuyrukBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KuyrukBir.Location = new System.Drawing.Point(131, 80);
            this.tbl2KuyrukBir.Name = "tbl2KuyrukBir";
            this.tbl2KuyrukBir.Size = new System.Drawing.Size(23, 15);
            this.tbl2KuyrukBir.TabIndex = 5;
            this.tbl2KuyrukBir.Text = "----";
            // 
            // tbl2KatBir
            // 
            this.tbl2KatBir.AutoSize = true;
            this.tbl2KatBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KatBir.Location = new System.Drawing.Point(42, 80);
            this.tbl2KatBir.Name = "tbl2KatBir";
            this.tbl2KatBir.Size = new System.Drawing.Size(38, 15);
            this.tbl2KatBir.TabIndex = 4;
            this.tbl2KatBir.Text = "1. Kat";
            // 
            // tbl2KuyrukZemin
            // 
            this.tbl2KuyrukZemin.AutoSize = true;
            this.tbl2KuyrukZemin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KuyrukZemin.Location = new System.Drawing.Point(131, 50);
            this.tbl2KuyrukZemin.Name = "tbl2KuyrukZemin";
            this.tbl2KuyrukZemin.Size = new System.Drawing.Size(23, 15);
            this.tbl2KuyrukZemin.TabIndex = 3;
            this.tbl2KuyrukZemin.Text = "----";
            // 
            // tbl2KatZemin
            // 
            this.tbl2KatZemin.AutoSize = true;
            this.tbl2KatZemin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl2KatZemin.Location = new System.Drawing.Point(32, 50);
            this.tbl2KatZemin.Name = "tbl2KatZemin";
            this.tbl2KatZemin.Size = new System.Drawing.Size(63, 15);
            this.tbl2KatZemin.TabIndex = 2;
            this.tbl2KatZemin.Text = "Zemin Kat";
            // 
            // tbl2KUYRUK
            // 
            this.tbl2KUYRUK.AutoSize = true;
            this.tbl2KUYRUK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.tbl2KUYRUK.Location = new System.Drawing.Point(131, 20);
            this.tbl2KUYRUK.Name = "tbl2KUYRUK";
            this.tbl2KUYRUK.Size = new System.Drawing.Size(63, 15);
            this.tbl2KUYRUK.TabIndex = 1;
            this.tbl2KUYRUK.Text = "KUYRUK";
            // 
            // tbl2KAT
            // 
            this.tbl2KAT.AutoSize = true;
            this.tbl2KAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.tbl2KAT.Location = new System.Drawing.Point(25, 20);
            this.tbl2KAT.Name = "tbl2KAT";
            this.tbl2KAT.Size = new System.Drawing.Size(84, 15);
            this.tbl2KAT.TabIndex = 0;
            this.tbl2KAT.Text = "KAT BİLGİSİ";
            // 
            // tbl1KuyrukDort
            // 
            this.tbl1KuyrukDort.AutoSize = true;
            this.tbl1KuyrukDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KuyrukDort.Location = new System.Drawing.Point(348, 170);
            this.tbl1KuyrukDort.Name = "tbl1KuyrukDort";
            this.tbl1KuyrukDort.Size = new System.Drawing.Size(23, 15);
            this.tbl1KuyrukDort.TabIndex = 14;
            this.tbl1KuyrukDort.Text = "----";
            // 
            // tbl1KuyrukUc
            // 
            this.tbl1KuyrukUc.AutoSize = true;
            this.tbl1KuyrukUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KuyrukUc.Location = new System.Drawing.Point(348, 140);
            this.tbl1KuyrukUc.Name = "tbl1KuyrukUc";
            this.tbl1KuyrukUc.Size = new System.Drawing.Size(23, 15);
            this.tbl1KuyrukUc.TabIndex = 13;
            this.tbl1KuyrukUc.Text = "----";
            // 
            // tbl1KuyrukIki
            // 
            this.tbl1KuyrukIki.AutoSize = true;
            this.tbl1KuyrukIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KuyrukIki.Location = new System.Drawing.Point(348, 110);
            this.tbl1KuyrukIki.Name = "tbl1KuyrukIki";
            this.tbl1KuyrukIki.Size = new System.Drawing.Size(23, 15);
            this.tbl1KuyrukIki.TabIndex = 12;
            this.tbl1KuyrukIki.Text = "----";
            // 
            // tbl1KuyrukBir
            // 
            this.tbl1KuyrukBir.AutoSize = true;
            this.tbl1KuyrukBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KuyrukBir.Location = new System.Drawing.Point(348, 80);
            this.tbl1KuyrukBir.Name = "tbl1KuyrukBir";
            this.tbl1KuyrukBir.Size = new System.Drawing.Size(23, 15);
            this.tbl1KuyrukBir.TabIndex = 11;
            this.tbl1KuyrukBir.Text = "----";
            // 
            // tbl1KuyrukZemin
            // 
            this.tbl1KuyrukZemin.AutoSize = true;
            this.tbl1KuyrukZemin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KuyrukZemin.Location = new System.Drawing.Point(348, 50);
            this.tbl1KuyrukZemin.Name = "tbl1KuyrukZemin";
            this.tbl1KuyrukZemin.Size = new System.Drawing.Size(23, 15);
            this.tbl1KuyrukZemin.TabIndex = 10;
            this.tbl1KuyrukZemin.Text = "----";
            // 
            // tbl1KUYRUKTABEKLEYENSAYISI
            // 
            this.tbl1KUYRUKTABEKLEYENSAYISI.AutoSize = true;
            this.tbl1KUYRUKTABEKLEYENSAYISI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.tbl1KUYRUKTABEKLEYENSAYISI.Location = new System.Drawing.Point(276, 20);
            this.tbl1KUYRUKTABEKLEYENSAYISI.Name = "tbl1KUYRUKTABEKLEYENSAYISI";
            this.tbl1KUYRUKTABEKLEYENSAYISI.Size = new System.Drawing.Size(200, 15);
            this.tbl1KUYRUKTABEKLEYENSAYISI.TabIndex = 9;
            this.tbl1KUYRUKTABEKLEYENSAYISI.Text = "KUYRUKTA BEKLEYEN SAYISI";
            // 
            // tbl1KISISAYISI
            // 
            this.tbl1KISISAYISI.AutoSize = true;
            this.tbl1KISISAYISI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.tbl1KISISAYISI.Location = new System.Drawing.Point(128, 20);
            this.tbl1KISISAYISI.Name = "tbl1KISISAYISI";
            this.tbl1KISISAYISI.Size = new System.Drawing.Size(138, 15);
            this.tbl1KISISAYISI.TabIndex = 8;
            this.tbl1KISISAYISI.Text = "TOPLAM KİŞİ SAYISI";
            // 
            // tbl1KATBILGISI
            // 
            this.tbl1KATBILGISI.AutoSize = true;
            this.tbl1KATBILGISI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.tbl1KATBILGISI.Location = new System.Drawing.Point(29, 20);
            this.tbl1KATBILGISI.Name = "tbl1KATBILGISI";
            this.tbl1KATBILGISI.Size = new System.Drawing.Size(84, 15);
            this.tbl1KATBILGISI.TabIndex = 7;
            this.tbl1KATBILGISI.Text = "KAT BİLGİSİ";
            // 
            // tbl1KatBilgDortKt
            // 
            this.tbl1KatBilgDortKt.AutoSize = true;
            this.tbl1KatBilgDortKt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KatBilgDortKt.Location = new System.Drawing.Point(46, 170);
            this.tbl1KatBilgDortKt.Name = "tbl1KatBilgDortKt";
            this.tbl1KatBilgDortKt.Size = new System.Drawing.Size(38, 15);
            this.tbl1KatBilgDortKt.TabIndex = 5;
            this.tbl1KatBilgDortKt.Text = "4. Kat";
            // 
            // tbl1KisiSayisiDort
            // 
            this.tbl1KisiSayisiDort.AutoSize = true;
            this.tbl1KisiSayisiDort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KisiSayisiDort.Location = new System.Drawing.Point(186, 170);
            this.tbl1KisiSayisiDort.Name = "tbl1KisiSayisiDort";
            this.tbl1KisiSayisiDort.Size = new System.Drawing.Size(23, 15);
            this.tbl1KisiSayisiDort.TabIndex = 6;
            this.tbl1KisiSayisiDort.Text = "----";
            // 
            // tbl1KisiSayisiUc
            // 
            this.tbl1KisiSayisiUc.AutoSize = true;
            this.tbl1KisiSayisiUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KisiSayisiUc.Location = new System.Drawing.Point(186, 140);
            this.tbl1KisiSayisiUc.Name = "tbl1KisiSayisiUc";
            this.tbl1KisiSayisiUc.Size = new System.Drawing.Size(23, 15);
            this.tbl1KisiSayisiUc.TabIndex = 4;
            this.tbl1KisiSayisiUc.Text = "----";
            // 
            // tbl1KatBilgUcKt
            // 
            this.tbl1KatBilgUcKt.AutoSize = true;
            this.tbl1KatBilgUcKt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KatBilgUcKt.Location = new System.Drawing.Point(47, 140);
            this.tbl1KatBilgUcKt.Name = "tbl1KatBilgUcKt";
            this.tbl1KatBilgUcKt.Size = new System.Drawing.Size(35, 15);
            this.tbl1KatBilgUcKt.TabIndex = 4;
            this.tbl1KatBilgUcKt.Text = "3.Kat";
            // 
            // tbl1KatBilgIkiKt
            // 
            this.tbl1KatBilgIkiKt.AutoSize = true;
            this.tbl1KatBilgIkiKt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KatBilgIkiKt.Location = new System.Drawing.Point(47, 110);
            this.tbl1KatBilgIkiKt.Name = "tbl1KatBilgIkiKt";
            this.tbl1KatBilgIkiKt.Size = new System.Drawing.Size(35, 15);
            this.tbl1KatBilgIkiKt.TabIndex = 3;
            this.tbl1KatBilgIkiKt.Text = "2.Kat";
            // 
            // tbl1KatBilgBirKt
            // 
            this.tbl1KatBilgBirKt.AutoSize = true;
            this.tbl1KatBilgBirKt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KatBilgBirKt.Location = new System.Drawing.Point(46, 80);
            this.tbl1KatBilgBirKt.Name = "tbl1KatBilgBirKt";
            this.tbl1KatBilgBirKt.Size = new System.Drawing.Size(38, 15);
            this.tbl1KatBilgBirKt.TabIndex = 2;
            this.tbl1KatBilgBirKt.Text = "1. Kat";
            // 
            // tbl1KatBilgZeminKt
            // 
            this.tbl1KatBilgZeminKt.AutoSize = true;
            this.tbl1KatBilgZeminKt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KatBilgZeminKt.Location = new System.Drawing.Point(36, 50);
            this.tbl1KatBilgZeminKt.Name = "tbl1KatBilgZeminKt";
            this.tbl1KatBilgZeminKt.Size = new System.Drawing.Size(63, 15);
            this.tbl1KatBilgZeminKt.TabIndex = 1;
            this.tbl1KatBilgZeminKt.Text = "Zemin Kat";
            // 
            // tbl1KisiSayisiIki
            // 
            this.tbl1KisiSayisiIki.AutoSize = true;
            this.tbl1KisiSayisiIki.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KisiSayisiIki.Location = new System.Drawing.Point(186, 110);
            this.tbl1KisiSayisiIki.Name = "tbl1KisiSayisiIki";
            this.tbl1KisiSayisiIki.Size = new System.Drawing.Size(23, 15);
            this.tbl1KisiSayisiIki.TabIndex = 3;
            this.tbl1KisiSayisiIki.Text = "----";
            // 
            // tbl1KisiSayisiBir
            // 
            this.tbl1KisiSayisiBir.AutoSize = true;
            this.tbl1KisiSayisiBir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KisiSayisiBir.Location = new System.Drawing.Point(186, 80);
            this.tbl1KisiSayisiBir.Name = "tbl1KisiSayisiBir";
            this.tbl1KisiSayisiBir.Size = new System.Drawing.Size(23, 15);
            this.tbl1KisiSayisiBir.TabIndex = 2;
            this.tbl1KisiSayisiBir.Text = "----";
            // 
            // tbl1KisiSayisiZemin
            // 
            this.tbl1KisiSayisiZemin.AutoSize = true;
            this.tbl1KisiSayisiZemin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tbl1KisiSayisiZemin.Location = new System.Drawing.Point(186, 50);
            this.tbl1KisiSayisiZemin.Name = "tbl1KisiSayisiZemin";
            this.tbl1KisiSayisiZemin.Size = new System.Drawing.Size(23, 15);
            this.tbl1KisiSayisiZemin.TabIndex = 1;
            this.tbl1KisiSayisiZemin.Text = "----";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(164)))), ((int)(((byte)(4)))));
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(268, 30);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(33, 13);
            this.label56.TabIndex = 6;
            this.label56.Text = "Aktif";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label57.Location = new System.Drawing.Point(307, 30);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(194, 13);
            this.label57.TabIndex = 7;
            this.label57.Text = "--> Asansör aktif şekilde çalışıyor";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label66.Location = new System.Drawing.Point(60, 30);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(154, 13);
            this.label66.TabIndex = 11;
            this.label66.Text = "--> Asansör pasif durumda";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(66)))), ((int)(((byte)(106)))));
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label72.ForeColor = System.Drawing.Color.White;
            this.label72.Location = new System.Drawing.Point(13, 30);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(35, 13);
            this.label72.TabIndex = 10;
            this.label72.Text = "Pasif";
            // 
            // LoginThreadCount
            // 
            this.LoginThreadCount.AutoSize = true;
            this.LoginThreadCount.Cursor = System.Windows.Forms.Cursors.No;
            this.LoginThreadCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.LoginThreadCount.Location = new System.Drawing.Point(13, 36);
            this.LoginThreadCount.Name = "LoginThreadCount";
            this.LoginThreadCount.Size = new System.Drawing.Size(214, 13);
            this.LoginThreadCount.TabIndex = 12;
            this.LoginThreadCount.Text = "Giriş Yapan Toplam Müşteri Sayısı: 0";
            // 
            // StartBtn
            // 
            this.StartBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(164)))), ((int)(((byte)(4)))));
            this.StartBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StartBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.StartBtn.ForeColor = System.Drawing.Color.White;
            this.StartBtn.Location = new System.Drawing.Point(12, 477);
            this.StartBtn.Name = "StartBtn";
            this.StartBtn.Size = new System.Drawing.Size(164, 175);
            this.StartBtn.TabIndex = 14;
            this.StartBtn.Text = "Başlat";
            this.StartBtn.UseVisualStyleBackColor = false;
            this.StartBtn.Click += new System.EventHandler(this.StartBtn_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label63.Location = new System.Drawing.Point(97, 71);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(404, 13);
            this.label63.TabIndex = 16;
            this.label63.Text = "--> Asansör içerisinde bulunan yolcuları indirip pasif konuma geçiriliyor";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(146)))), ((int)(((byte)(184)))));
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label65.ForeColor = System.Drawing.Color.White;
            this.label65.Location = new System.Drawing.Point(12, 71);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(79, 13);
            this.label65.TabIndex = 15;
            this.label65.Text = "Durduruluyor";
            // 
            // LogoutThreadCount
            // 
            this.LogoutThreadCount.AutoSize = true;
            this.LogoutThreadCount.Cursor = System.Windows.Forms.Cursors.No;
            this.LogoutThreadCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.LogoutThreadCount.Location = new System.Drawing.Point(13, 77);
            this.LogoutThreadCount.Name = "LogoutThreadCount";
            this.LogoutThreadCount.Size = new System.Drawing.Size(216, 13);
            this.LogoutThreadCount.TabIndex = 18;
            this.LogoutThreadCount.Text = "Çıkış Yapan Toplam Müşteri Sayısı: 0";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbl1KATBILGISI);
            this.groupBox1.Controls.Add(this.tbl1KisiSayisiZemin);
            this.groupBox1.Controls.Add(this.tbl1KatBilgZeminKt);
            this.groupBox1.Controls.Add(this.tbl1KisiSayisiBir);
            this.groupBox1.Controls.Add(this.tbl1KatBilgBirKt);
            this.groupBox1.Controls.Add(this.tbl1KatBilgIkiKt);
            this.groupBox1.Controls.Add(this.tbl1KisiSayisiIki);
            this.groupBox1.Controls.Add(this.tbl1KatBilgUcKt);
            this.groupBox1.Controls.Add(this.tbl1KuyrukZemin);
            this.groupBox1.Controls.Add(this.tbl1KisiSayisiUc);
            this.groupBox1.Controls.Add(this.tbl1KatBilgDortKt);
            this.groupBox1.Controls.Add(this.tbl1KisiSayisiDort);
            this.groupBox1.Controls.Add(this.tbl1KuyrukBir);
            this.groupBox1.Controls.Add(this.tbl1KuyrukIki);
            this.groupBox1.Controls.Add(this.tbl1KuyrukUc);
            this.groupBox1.Controls.Add(this.tbl1KISISAYISI);
            this.groupBox1.Controls.Add(this.tbl1KuyrukDort);
            this.groupBox1.Controls.Add(this.tbl1KUYRUKTABEKLEYENSAYISI);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(508, 222);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ANLIK KAT BİLGİLERİ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbl2KAT);
            this.groupBox2.Controls.Add(this.tbl2KUYRUK);
            this.groupBox2.Controls.Add(this.tbl2KatZemin);
            this.groupBox2.Controls.Add(this.tbl2KatBir);
            this.groupBox2.Controls.Add(this.tbl2KatIki);
            this.groupBox2.Controls.Add(this.tbl2KatUc);
            this.groupBox2.Controls.Add(this.tbl2KuyrukZemin);
            this.groupBox2.Controls.Add(this.tbl2KuyrukDort);
            this.groupBox2.Controls.Add(this.tbl2KuyrukBir);
            this.groupBox2.Controls.Add(this.tbl2KuyrukIki);
            this.groupBox2.Controls.Add(this.tbl2KatDort);
            this.groupBox2.Controls.Add(this.tbl2KuyrukUc);
            this.groupBox2.Location = new System.Drawing.Point(535, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(461, 222);
            this.groupBox2.TabIndex = 59;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "KATLARDA OLUŞAN KUYRUKLAR";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbl3Asansor);
            this.groupBox3.Controls.Add(this.tbl3ANLIK);
            this.groupBox3.Controls.Add(this.tbl3KuyrukDort);
            this.groupBox3.Controls.Add(this.tbl3AsansorSifir);
            this.groupBox3.Controls.Add(this.tbl3ModDort);
            this.groupBox3.Controls.Add(this.tbl3AsansorBir);
            this.groupBox3.Controls.Add(this.tbl3KuyrukUc);
            this.groupBox3.Controls.Add(this.tbl3HEDEF);
            this.groupBox3.Controls.Add(this.tbl3ModUc);
            this.groupBox3.Controls.Add(this.tbl3YON);
            this.groupBox3.Controls.Add(this.tbl3KuyrukIki);
            this.groupBox3.Controls.Add(this.tbl3AsansorIki);
            this.groupBox3.Controls.Add(this.tbl3KuyrukBir);
            this.groupBox3.Controls.Add(this.tbl3AsansorUc);
            this.groupBox3.Controls.Add(this.tbl3KuyrukSifir);
            this.groupBox3.Controls.Add(this.tbl3KAT);
            this.groupBox3.Controls.Add(this.tbl3AnlikDort);
            this.groupBox3.Controls.Add(this.tbl3AsansorDort);
            this.groupBox3.Controls.Add(this.tbl3MOD);
            this.groupBox3.Controls.Add(this.tbl3AnlikUc);
            this.groupBox3.Controls.Add(this.tbl3KatSifir);
            this.groupBox3.Controls.Add(this.tbl3YonDort);
            this.groupBox3.Controls.Add(this.tbl3KatBir);
            this.groupBox3.Controls.Add(this.tbl3AnlikIki);
            this.groupBox3.Controls.Add(this.tbl3KatIki);
            this.groupBox3.Controls.Add(this.tbl3AnlikBir);
            this.groupBox3.Controls.Add(this.tbl3ModSifir);
            this.groupBox3.Controls.Add(this.tbl3AnlikSifir);
            this.groupBox3.Controls.Add(this.tbl3ModBir);
            this.groupBox3.Controls.Add(this.tbl3HedefSifir);
            this.groupBox3.Controls.Add(this.tbl3HedefDort);
            this.groupBox3.Controls.Add(this.tbl3HedefBir);
            this.groupBox3.Controls.Add(this.tbl3YonUc);
            this.groupBox3.Controls.Add(this.tbl3HedefIki);
            this.groupBox3.Controls.Add(this.tbl3KatDort);
            this.groupBox3.Controls.Add(this.tbl3ModIki);
            this.groupBox3.Controls.Add(this.tbl3YonSifir);
            this.groupBox3.Controls.Add(this.tbl3HedefUc);
            this.groupBox3.Controls.Add(this.tbl3YonBir);
            this.groupBox3.Controls.Add(this.tbl3YonIki);
            this.groupBox3.Controls.Add(this.tbl3KUYRUK);
            this.groupBox3.Controls.Add(this.tbl3KatUc);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Location = new System.Drawing.Point(12, 240);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(984, 231);
            this.groupBox3.TabIndex = 60;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ASANSÖRLER VE BİLGİLERİ";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.LogoutThreadCount);
            this.groupBox4.Controls.Add(this.LoginThreadCount);
            this.groupBox4.Location = new System.Drawing.Point(183, 477);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(302, 108);
            this.groupBox4.TabIndex = 61;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Hareket Bilgileri";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label63);
            this.groupBox5.Controls.Add(this.label56);
            this.groupBox5.Controls.Add(this.label57);
            this.groupBox5.Controls.Add(this.label72);
            this.groupBox5.Controls.Add(this.label66);
            this.groupBox5.Controls.Add(this.label65);
            this.groupBox5.Location = new System.Drawing.Point(491, 477);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(505, 108);
            this.groupBox5.TabIndex = 62;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "İşaret ve Semboller";
            // 
            // CapacityLbl
            // 
            this.CapacityLbl.AutoSize = true;
            this.CapacityLbl.Cursor = System.Windows.Forms.Cursors.No;
            this.CapacityLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.CapacityLbl.Location = new System.Drawing.Point(15, 33);
            this.CapacityLbl.Name = "CapacityLbl";
            this.CapacityLbl.Size = new System.Drawing.Size(198, 13);
            this.CapacityLbl.TabIndex = 19;
            this.CapacityLbl.Text = "Maksimum Asansör Kapasitesi: 10";
            // 
            // LoginThreadSpeedLbl
            // 
            this.LoginThreadSpeedLbl.AutoSize = true;
            this.LoginThreadSpeedLbl.Cursor = System.Windows.Forms.Cursors.No;
            this.LoginThreadSpeedLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.LoginThreadSpeedLbl.Location = new System.Drawing.Point(245, 33);
            this.LoginThreadSpeedLbl.Name = "LoginThreadSpeedLbl";
            this.LoginThreadSpeedLbl.Size = new System.Drawing.Size(151, 13);
            this.LoginThreadSpeedLbl.TabIndex = 20;
            this.LoginThreadSpeedLbl.Text = "Login Thread Hızı: 500ms";
            // 
            // ExitThreadSpeedLbl
            // 
            this.ExitThreadSpeedLbl.AutoSize = true;
            this.ExitThreadSpeedLbl.Cursor = System.Windows.Forms.Cursors.No;
            this.ExitThreadSpeedLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.ExitThreadSpeedLbl.Location = new System.Drawing.Point(434, 33);
            this.ExitThreadSpeedLbl.Name = "ExitThreadSpeedLbl";
            this.ExitThreadSpeedLbl.Size = new System.Drawing.Size(141, 13);
            this.ExitThreadSpeedLbl.TabIndex = 21;
            this.ExitThreadSpeedLbl.Text = "Exit Thread Hızı: 500ms";
            // 
            // ElevatorSpeedLbl
            // 
            this.ElevatorSpeedLbl.AutoSize = true;
            this.ElevatorSpeedLbl.Cursor = System.Windows.Forms.Cursors.No;
            this.ElevatorSpeedLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.ElevatorSpeedLbl.Location = new System.Drawing.Point(616, 33);
            this.ElevatorSpeedLbl.Name = "ElevatorSpeedLbl";
            this.ElevatorSpeedLbl.Size = new System.Drawing.Size(165, 13);
            this.ElevatorSpeedLbl.TabIndex = 22;
            this.ElevatorSpeedLbl.Text = "Asansör Thread Hızı: 500ms";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ElevatorSpeedLbl);
            this.groupBox6.Controls.Add(this.CapacityLbl);
            this.groupBox6.Controls.Add(this.ExitThreadSpeedLbl);
            this.groupBox6.Controls.Add(this.LoginThreadSpeedLbl);
            this.groupBox6.Location = new System.Drawing.Point(183, 591);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(813, 61);
            this.groupBox6.TabIndex = 63;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Genel Ayarlar";
            // 
            // ShoppingMallInformationDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1007, 664);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.StartBtn);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ShoppingMallInformationDisplay";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alışveriş Merkezi Bilgi Ekranı";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShoppingMallInformationDisplay_FormClosing);
            this.Load += new System.EventHandler(this.ShoppingMallInformationDisplay_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label tbl1KuyrukDort;
        private System.Windows.Forms.Label tbl1KuyrukUc;
        private System.Windows.Forms.Label tbl1KuyrukIki;
        private System.Windows.Forms.Label tbl1KuyrukBir;
        private System.Windows.Forms.Label tbl1KuyrukZemin;
        private System.Windows.Forms.Label tbl1KUYRUKTABEKLEYENSAYISI;
        private System.Windows.Forms.Label tbl1KISISAYISI;
        private System.Windows.Forms.Label tbl1KATBILGISI;
        private System.Windows.Forms.Label tbl1KatBilgDortKt;
        private System.Windows.Forms.Label tbl1KisiSayisiDort;
        private System.Windows.Forms.Label tbl1KisiSayisiUc;
        private System.Windows.Forms.Label tbl1KatBilgUcKt;
        private System.Windows.Forms.Label tbl1KatBilgIkiKt;
        private System.Windows.Forms.Label tbl1KatBilgBirKt;
        private System.Windows.Forms.Label tbl1KatBilgZeminKt;
        private System.Windows.Forms.Label tbl1KisiSayisiIki;
        private System.Windows.Forms.Label tbl1KisiSayisiBir;
        private System.Windows.Forms.Label tbl1KisiSayisiZemin;
        private System.Windows.Forms.Label tbl3AnlikDort;
        private System.Windows.Forms.Label tbl3YonDort;
        private System.Windows.Forms.Label tbl3HedefDort;
        private System.Windows.Forms.Label tbl3KatDort;
        private System.Windows.Forms.Label tbl3AsansorDort;
        private System.Windows.Forms.Label tbl3AnlikUc;
        private System.Windows.Forms.Label tbl3YonUc;
        private System.Windows.Forms.Label tbl3HedefUc;
        private System.Windows.Forms.Label tbl3KatUc;
        private System.Windows.Forms.Label tbl3AsansorUc;
        private System.Windows.Forms.Label tbl3AnlikIki;
        private System.Windows.Forms.Label tbl3YonIki;
        private System.Windows.Forms.Label tbl3HedefIki;
        private System.Windows.Forms.Label tbl3KatIki;
        private System.Windows.Forms.Label tbl3AsansorIki;
        private System.Windows.Forms.Label tbl3AnlikBir;
        private System.Windows.Forms.Label tbl3YonBir;
        private System.Windows.Forms.Label tbl3HedefBir;
        private System.Windows.Forms.Label tbl3KatBir;
        private System.Windows.Forms.Label tbl3ModBir;
        private System.Windows.Forms.Label tbl3AsansorBir;
        private System.Windows.Forms.Label tbl3AnlikSifir;
        private System.Windows.Forms.Label tbl3YonSifir;
        private System.Windows.Forms.Label tbl3HedefSifir;
        private System.Windows.Forms.Label tbl3KatSifir;
        private System.Windows.Forms.Label tbl3ModSifir;
        private System.Windows.Forms.Label tbl3AsansorSifir;
        private System.Windows.Forms.Label tbl3KAT;
        private System.Windows.Forms.Label tbl3MOD;
        private System.Windows.Forms.Label tbl3Asansor;
        private System.Windows.Forms.Label tbl3HEDEF;
        private System.Windows.Forms.Label tbl3YON;
        private System.Windows.Forms.Label tbl3ANLIK;
        private System.Windows.Forms.Label tbl2KatDort;
        private System.Windows.Forms.Label tbl2KuyrukDort;
        private System.Windows.Forms.Label tbl2KuyrukUc;
        private System.Windows.Forms.Label tbl2KatUc;
        private System.Windows.Forms.Label tbl2KuyrukIki;
        private System.Windows.Forms.Label tbl2KatIki;
        private System.Windows.Forms.Label tbl2KuyrukBir;
        private System.Windows.Forms.Label tbl2KatBir;
        private System.Windows.Forms.Label tbl2KuyrukZemin;
        private System.Windows.Forms.Label tbl2KatZemin;
        private System.Windows.Forms.Label tbl2KUYRUK;
        private System.Windows.Forms.Label tbl2KAT;
        private System.Windows.Forms.Label tbl3ModUc;
        private System.Windows.Forms.Label tbl3ModDort;
        private System.Windows.Forms.Label tbl3KuyrukDort;
        private System.Windows.Forms.Label tbl3KuyrukUc;
        private System.Windows.Forms.Label tbl3ModIki;
        private System.Windows.Forms.Label tbl3KuyrukIki;
        private System.Windows.Forms.Label tbl3KuyrukBir;
        private System.Windows.Forms.Label tbl3KuyrukSifir;
        private System.Windows.Forms.Label tbl3KUYRUK;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label LoginThreadCount;
        private System.Windows.Forms.Button StartBtn;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label LogoutThreadCount;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label CapacityLbl;
        private System.Windows.Forms.Label LoginThreadSpeedLbl;
        private System.Windows.Forms.Label ExitThreadSpeedLbl;
        private System.Windows.Forms.Label ElevatorSpeedLbl;
        private System.Windows.Forms.GroupBox groupBox6;
    }
}

